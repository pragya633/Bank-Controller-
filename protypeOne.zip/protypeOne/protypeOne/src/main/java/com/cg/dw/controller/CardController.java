package com.cg.dw.controller;

import java.math.BigInteger;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.cg.dw.exception.IBSException;
import com.cg.dw.service.DepartmentService;

@Controller
public class CardController {
	@Autowired
	private DepartmentService deptService;

	@RequestMapping("/cards")
	public ModelAndView showCardHome() {
		return new ModelAndView("cardsHomePage", "depts", deptService.findAll());
	}

	@RequestMapping("/cardMenu")
	public String showDeptsMenu() {
		return "cardsMenuPage";
	}

	

}
