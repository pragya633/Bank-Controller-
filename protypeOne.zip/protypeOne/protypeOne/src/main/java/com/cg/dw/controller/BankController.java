package com.cg.dw.controller;

import java.math.BigInteger;
import java.util.List;

import com.cg.dw.exception.IBSException;
import com.cg.dw.model.CaseIdBean;
import com.cg.dw.model.DebitCardBean;
import com.cg.dw.service.BankService;

@Controller
@Scope("session")
public class BankController {
	
	String serviceRequest;
	String serviceRequest1;
	String output="";
	@Autowired
	private BankService bankService;
     CaseIdBean caseBean = new CaseIdBean();
	
	@RequestMapping(value = "/bank", method = RequestMethod.GET)
	public String goToBank() {
		return "bankHomePage";
	} 
	
	@RequestMapping("/bankMenu")
	public String showMenu() {
		return "bankMenuPage";
	}
	
	@RequestMapping("/listsr")
	public ModelAndView showServieRequests() {
		return new ModelAndView("bankSubMenuPage");
	}
	
	@RequestMapping(value = "/newdebit", method = RequestMethod.GET)
    public ModelAndView listNewDebitQueries() {
        List<CaseIdBean> caseBeans;
        try {
        	caseBeans = bankService.viewNewDebitQueries();
        } catch (IBSException e) {
            String message = e.getMessage();
            return new ModelAndView("errorPage", "errorMessage", message);
        }
        return new ModelAndView("listnewDebitQueries", "output", caseBeans);
    }
	
	@RequestMapping("/replyQueries")
	public ModelAndView replyQueries(@RequestParam("serviceRequest") String serviceRequest1) {
		this.serviceRequest=serviceRequest1;
		return new ModelAndView("replyQueryPage");
	}
	
	@RequestMapping("/replyQueries", method = RequestMethod.POST)
	public ModelAndView replyQueries(@RequestParam("status") String status, @RequestParam("remarks") String remarks) {
		serviceRequest1=this.serviceRequest;
		
			if (serviceRequest1.contains("RDMT") || serviceRequest1.contains("RCMT")) {
				checkMismatch(serviceRequest1);
			}
			else {
				try {
			bankService.setQueryStatus(serviceRequest1, status,remarks);
			output="Replied successfully to the query";
		} catch (IBSException e) {
			output = e.getMessage();
			return new ModelAndView("errorPage", "output", output);
		}}
		return new ModelAndView("outputPage", "output", output);
	}
	
	public void checkMismatch(String queryId) {
		try {
			if (bankService.checkMismatchDebit(queryId)) {
				//ADD THIS...........
				checkMismatchDebit(queryId);
			}
			if (bankService.checkMismatchCredit(queryId)) {
				
				checkMismatchCredit(queryId);
			}
		} catch (IBSException e) {
		}
	}
	
	
	
	@RequestMapping(value = "/newdcredit", method = RequestMethod.GET)
    public ModelAndView listNewCreditQueries() {
        List<CaseIdBean> caseBeans;
        try {
        	caseBeans = bankService.viewNewCreditQueries();
        } catch (IBSException e) {
            String message = e.getMessage();
            return new ModelAndView("errorPage", "errorMessage", message);
        }
        return new ModelAndView("listnewCreditQueries", "output", caseBeans);
    }
	
	
	@RequestMapping(value = "/upgradedebit", method = RequestMethod.GET)
    public ModelAndView listNewUpgradeDebitQueries() {
        List<CaseIdBean> caseBeans;
        try {
        	caseBeans = bankService.viewDebitUpgradeQueries();
        } catch (IBSException e) {
            String message = e.getMessage();
            return new ModelAndView("errorPage", "errorMessage", message);
        }
        return new ModelAndView("listnewUpgradeQueries", "output", caseBeans);
    }
	
	
	@RequestMapping(value = "/upgradecredit", method = RequestMethod.GET)
    public ModelAndView listNewUpgradeCreditQueries() {
        List<CaseIdBean> caseBeans;
        try {
        	caseBeans = bankService.viewCreditUgradeQueries();
        } catch (IBSException e) {
            String message = e.getMessage();
            return new ModelAndView("errorPage", "errorMessage", message);
        }
        return new ModelAndView("serviceRequests", "output", caseBeans);
    }
	
	@RequestMapping(value = "/reqdebit", method = RequestMethod.GET)
    public ModelAndView listNewCreditQueries() {
        List<CaseIdBean> caseBeans;
        try {
        	caseBeans = bankService.viewDebitMismatchQueries();
        } catch (IBSException e) {
            String message = e.getMessage();
            return new ModelAndView("errorPage", "errorMessage", message);
        }
        return new ModelAndView("serviceRequests", "output", caseBeans);
    }
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	

}
