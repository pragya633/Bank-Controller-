package com.cg.dw.dao;

public interface BankDao {

}
